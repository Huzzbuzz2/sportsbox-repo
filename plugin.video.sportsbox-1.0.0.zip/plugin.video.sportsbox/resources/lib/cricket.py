import requests
import xbmcgui
import xbmcplugin
import xbmc
import json

API_URL = 'https://sportsbox-server.onrender.com/matches'

HEADERS = {
    'User-Agent': 'Mozilla/5.0',
}


def get_matches():
    try:
        r = requests.get(API_URL, headers=HEADERS, timeout=30)
        data = r.json()
        return data.get('matches', [])
    except Exception as e:
        xbmc.log('SportsBox: API error: ' + str(e), xbmc.LOGERROR)
        return []


def show_schedule(handle, build_url):
    matches = get_matches()

    if not matches:
        li = xbmcgui.ListItem('No matches available - check connection')
        xbmcplugin.addDirectoryItem(handle, '', li, isFolder=False)
        xbmcplugin.endOfDirectory(handle)
        return

    for match in matches:
        title = match.get('title', 'Cricket Match')
        streams = match.get('streams', [])
        real_streams = [s for s in streams if 'm3u8' in s.get('url', '')]
        if not real_streams:
            continue

        label = title + ' (' + str(len(real_streams)) + ' streams)'
        url_params = {
            'action': 'cricket_streams',
            'match_title': title,
            'stream_count': str(len(real_streams))
        }
        for i, s in enumerate(real_streams):
            url_params['stream_' + str(i) + '_label'] = s['label']
            url_params['stream_' + str(i) + '_url'] = s['url']
            # Pass headers
            h = s.get('headers', {})
            url_params['stream_' + str(i) + '_referer'] = h.get('Referer', 'https://one.timesup.top/')
            url_params['stream_' + str(i) + '_origin'] = h.get('Origin', 'https://one.timesup.top')
            url_params['stream_' + str(i) + '_ua'] = h.get('User-Agent', '')

        url = build_url(url_params)
        li = xbmcgui.ListItem(label)
        li.setArt({'icon': 'DefaultVideo.png'})
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)

    xbmcplugin.setContent(handle, 'files')
    xbmcplugin.endOfDirectory(handle)


def list_matches(handle, build_url):
    show_schedule(handle, build_url)


def show_streams(handle, build_url, params):
    stream_count = int(params.get('stream_count', 0))

    if stream_count == 0:
        li = xbmcgui.ListItem('No streams available')
        xbmcplugin.addDirectoryItem(handle, '', li, isFolder=False)
        xbmcplugin.endOfDirectory(handle)
        return

    for i in range(stream_count):
        label = params.get('stream_' + str(i) + '_label', 'Stream ' + str(i + 1))
        url = params.get('stream_' + str(i) + '_url', '')
        referer = params.get('stream_' + str(i) + '_referer', 'https://one.timesup.top/')
        origin = params.get('stream_' + str(i) + '_origin', 'https://one.timesup.top')
        ua = params.get('stream_' + str(i) + '_ua', '')

        if not url:
            continue

        play_url = build_url({
            'action': 'play',
            'url': url,
            'referer': referer,
            'origin': origin,
            'user_agent': ua
        })
        li = xbmcgui.ListItem(label)
        li.setProperty('IsPlayable', 'true')
        li.setArt({'icon': 'DefaultVideo.png'})
        xbmcplugin.addDirectoryItem(handle, play_url, li, isFolder=False)

    xbmcplugin.setContent(handle, 'files')
    xbmcplugin.endOfDirectory(handle)
