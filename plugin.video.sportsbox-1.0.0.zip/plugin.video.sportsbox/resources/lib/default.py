import sys
from urllib.parse import parse_qsl, urlencode
import xbmcplugin
import xbmcgui
import xbmcaddon
from resources.lib import cricket

HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON = xbmcaddon.Addon()


def build_url(params):
    return BASE_URL + '?' + urlencode(params)


def main_menu():
    items = [
        ("Today's Schedule", 'schedule'),
        ('Cricket', 'cricket_list'),
    ]
    for label, action in items:
        url = build_url({'action': action})
        li = xbmcgui.ListItem(label)
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    xbmcplugin.setContent(HANDLE, 'files')
    xbmcplugin.endOfDirectory(HANDLE)


def router():
    params = dict(parse_qsl(sys.argv[2][1:]))
    action = params.get('action', '')

    if not action:
        main_menu()

    elif action == 'schedule':
        cricket.show_schedule(HANDLE, build_url)

    elif action == 'cricket_list':
        cricket.list_matches(HANDLE, build_url)

    elif action == 'cricket_streams':
        cricket.show_streams(HANDLE, build_url, params)

    elif action == 'play':
        url = params.get('url', '')
        referer = params.get('referer', 'https://one.timesup.top/')
        origin = params.get('origin', 'https://one.timesup.top')
        user_agent = params.get('user_agent', 'Mozilla/5.0 (Linux; Android 11; Mobile) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36')

        headers = 'Referer={}&Origin={}&User-Agent={}'.format(referer, origin, user_agent)

        li = xbmcgui.ListItem(path=url)
        li.setMimeType('application/x-mpegURL')
        li.setContentLookup(False)
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        li.setProperty('inputstream.adaptive.stream_headers', headers)
        li.setProperty('inputstream.adaptive.manifest_headers', headers)
        xbmcplugin.setResolvedUrl(HANDLE, True, li)


router()
