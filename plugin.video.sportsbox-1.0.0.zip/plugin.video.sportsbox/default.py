import sys
from urllib.parse import parse_qsl, urlencode
import xbmcplugin
import xbmcgui
import xbmcaddon
from resources.lib import cricket

HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON = xbmcaddon.Addon()


def build_url(params):
    return BASE_URL + '?' + urlencode(params)


def main_menu():
    items = [
        ('Today\'s Schedule', 'schedule'),
        ('Cricket',           'cricket_list'),
    ]
    for label, action in items:
        url = build_url({'action': action})
        li = xbmcgui.ListItem(label)
        li.setInfo('video', {'title': label})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    xbmcplugin.setContent(HANDLE, 'files')
    xbmcplugin.endOfDirectory(HANDLE)


def router():
    params = dict(parse_qsl(sys.argv[2][1:]))
    action = params.get('action', '')

    if not action:
        main_menu()

    elif action == 'schedule':
        cricket.show_schedule(HANDLE, build_url)

    elif action == 'cricket_list':
        cricket.list_matches(HANDLE, build_url)

    elif action == 'cricket_streams':
        # params contains match_title and all stream_X keys
        cricket.show_streams(HANDLE, build_url, params)

    elif action == 'play':
        url = params.get('url', '')
        li = xbmcgui.ListItem(path=url)
        li.setMimeType('application/x-mpegURL')
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(HANDLE, True, li)


router()
